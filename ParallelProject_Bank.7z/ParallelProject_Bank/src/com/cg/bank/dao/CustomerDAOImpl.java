package com.cg.bank.dao;



import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;


public class CustomerDAOImpl implements CustomerDAO {
CollectionUtil cu=new CollectionUtil();
	@Override
	public HashMap<Integer, Account> showBalance(int accid) {
		 HashMap<Integer, Account> w =cu.showBalance(accid);
			return w;
	}

	@Override
	public HashMap<Integer, Customer> validateMob(String mobno) {
		HashMap<Integer, Customer>hm =cu.validateMob(mobno);
		return hm;
	}

	@Override
	public void addCustomer(int cusid, Account account) {
		cu.addCustomer (cusid, account);
		
	}

}
