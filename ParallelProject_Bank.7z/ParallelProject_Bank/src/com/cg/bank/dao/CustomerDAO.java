package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;



public interface CustomerDAO {
	abstract HashMap<Integer, Account> showBalance(int accid);

	abstract HashMap<Integer, Customer> validateMob(String mobno);

	abstract void addCustomer(int cusid, Account account);

}
