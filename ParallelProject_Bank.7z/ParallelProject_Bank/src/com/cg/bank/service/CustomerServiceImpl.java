package com.cg.bank.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService {
	CustomerDAO cusdao = new CustomerDAOImpl();
	@Override
	public HashMap<Integer, Account> showBalance(int accid) {
		HashMap<Integer, Account> w= cusdao.showBalance(accid);
		return w;
	}

	@Override
	public HashMap<Integer, Customer> validateMob(String mobno) {
		HashMap<Integer, Customer>hm= cusdao.validateMob(mobno);
		return hm;
	}

	public boolean validateCustomerAddress(String customerAddress) throws CustomerException {
		Pattern pattern = Pattern.compile("[A-Za-z]{1,20}");
		Matcher customerAddressMatch = pattern.matcher(customerAddress);
		if (customerAddressMatch.matches())
		{
			return true;
		}
		return false;
	}
	
	public boolean validateCustomerName(String cusname) throws CustomerException {
		Pattern pattern = Pattern.compile("[A-Z]{1}[a-z]{1,10}");
		Matcher cusnameMatch = pattern.matcher(cusname);
		if (cusnameMatch.matches())
		{
			return true;
		}
		return false;
	}
	
	
	public boolean validateCustomerMobileNo(String customerMobileNo) throws CustomerException {
		Pattern pattern = Pattern.compile("[0-9]{10}");
		Matcher customerMobileNoMatch = pattern.matcher(customerMobileNo);
		if (customerMobileNoMatch.matches())
		{
			return true;
		}
		return false;
	}
	
	@Override
	public boolean validateAcctype(String acctype) throws CustomerException {
		String a1="Savings";
		String a2="Current";
		if (acctype.equals(a1) || acctype.equals(a2))
		{
			return true;
		}
		return false;
	}

	@Override
	public int addCustomer(int cusid, Account account) {
		cusdao.addCustomer( cusid, account);
		return 0;
	}

}
