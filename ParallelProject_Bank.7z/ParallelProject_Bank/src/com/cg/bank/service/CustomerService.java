package com.cg.bank.service;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerException;



public interface CustomerService {
	abstract HashMap<Integer, Account> showBalance(int accid);
	HashMap<Integer, Customer> validateMob(String mobno);
	boolean validateAcctype(String acctype) throws CustomerException;
	int addCustomer(int cusid,Account account);
	
	default boolean validateCustomerName(String cusname)  throws CustomerException
	{
		return false;
	}
	default boolean validateCustomerMobileNo(String customerMobileNo) throws CustomerException
	{
		return false;
	}
	default boolean validateCustomerAddress(String customerAddress) throws CustomerException
	{
		return false;
	}

}
