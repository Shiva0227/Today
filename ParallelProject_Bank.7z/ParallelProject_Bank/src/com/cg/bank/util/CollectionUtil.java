package com.cg.bank.util;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;



public class CollectionUtil {
public static HashMap<Integer, Customer> hm = new HashMap<>();
	
	static 
	{
		hm.put(1111, new Customer(1111,"Shiva","9989745236","Bangalore"));
		hm.put(1112, new Customer(1112,"Rayudu","8756545752","Electronic City"));
		hm.put(1113, new Customer(1113,"Nikhil","9002517798","J.P.Nagar"));
		hm.put(1114, new Customer(1114,"Kumar","9865741556","ShivajiNagar"));
		hm.put(1115, new Customer(1115,"Krishna","9738589457","Uttarahalli"));
	}
	
	public static HashMap<Integer, Account> am = new HashMap<>();
	
	static
	{
		am.put(1111, new Account (1111,"Savings","Jayanagar","CHE236",10000));
		am.put(1112, new Account (1112,"Current","Jayanagar","CHE236",12000));
		am.put(1113, new Account (1113,"Current","Jayanagar","CHE236",14000));
		am.put(1114, new Account (1115,"Savings","Jayanagar","CHE236",16000));
		am.put(1115, new Account (1116,"Savings","Jayanagar","CHE236",18000));
	}

	public HashMap<Integer, Account> showBalance(int accid)
	{
		if (am.containsKey(accid))
		{
			
		return am;
		}
		else
		{
			System.out.println("No such Account");
		}
		return null;		
	}

	public HashMap<Integer, Customer> validateMob(String mobno) {

		if(hm.containsValue(mobno))
				{
			System.out.println("got it");
			return hm;
				}
			return hm;
	}

	public void addCustomer(int cusid, Account account) {
		am.put(cusid, account);
		
	}


}
