package com.cg.mob.DAO;

import java.util.Map;

import com.cg.mob.Exception.MobileException;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.util.CollectionUtil;

public class MobileDAOImpl implements MobileDAO{

	@Override
	public Long getCstmrDetails(Long mblNo,Customer c) {
		CollectionUtil.getCstmrDetails(mblNo, c);
	return c.getCusCellNo();
	}

	@Override
	public Mobile placeOrder(String mobileModels){
		Mobile m=CollectionUtil.placeOrder(mobileModels);
		return m;
	}

	@Override
	public Mobile displayOrder(int orderId) {
		Mobile m=CollectionUtil.displayOrder(orderId);
		return m;
	
	}

	@Override
	public String getMobileDetails(String s,Mobile m) throws MobileException{
		CollectionUtil.getMobileDetails(s, m);
		return m.getMobileModels();
	}


}
