package com.cg.mob.DAO;

import java.util.Map;

import com.cg.mob.Exception.MobileException;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public interface MobileDAO {
	public Long getCstmrDetails(Long mblNo,Customer c);
	public Mobile placeOrder(String mobileModels) ;
	public String getMobileDetails(String s,Mobile m) throws MobileException;
	public Mobile displayOrder(int orderId);
}
