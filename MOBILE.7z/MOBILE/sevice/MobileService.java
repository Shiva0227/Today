package com.cg.mob.sevice;

import java.util.Map;

import com.cg.mob.Exception.MobileException;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public interface MobileService {
	
  	public Mobile placeOrder(String mobileModels);
	public Mobile displayOrder(int orderId);
  	public Long getCstmrDetails(Long mblNo,Customer c);
 	public String getMobileDetails(String s,Mobile m) throws MobileException;
public boolean validateCstmrName(String name);
public boolean valiateCstmrCellNo(String cellNo) ;
public boolean validateCstmrId(String cstmrId) ;
}
