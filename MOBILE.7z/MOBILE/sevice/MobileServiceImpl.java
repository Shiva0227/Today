package com.cg.mob.sevice;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mob.DAO.MobileDAO;
import com.cg.mob.DAO.MobileDAOImpl;
import com.cg.mob.Exception.MobileException;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public class MobileServiceImpl implements MobileService {
          MobileDAO cs=new MobileDAOImpl();
       
        	
        	  	
        	  	@Override
        	  	public boolean validateCstmrName(String name)  {
        	  		Pattern pattern=Pattern.compile("^^[A-Z]{1}[a-z]{1,10}");
        	  		Matcher m=pattern.matcher(name);
        	  		if(m.matches()) {
        	  			return true;
        	  		}
        	  		else {
        	  			return false;
        	  		}
        	  	
        	  	}

        	  	@Override
        	  	public boolean valiateCstmrCellNo(String cellNo) {
        	  		Pattern pattern=Pattern.compile("[0-9]{10}");
        	  		Matcher m=pattern.matcher(cellNo);
        	  		if(m.matches()) {
        	  			return true;
        	  		}
        	  		else {
        	  			return false;
        	  		}
        	  	
        	  		
        	  	}

        	  	@Override
        	  	public boolean validateCstmrId(String cstmrId)  {
        	  		Pattern pattern=Pattern.compile("[0-9]{5}");
        	  		Matcher m=pattern.matcher(cstmrId);
        	  		if(m.matches()) {
        	  			return true;
        	  		}
        	  		else {
        	  			return false;
        	  		}
        	  	
        	  		
        	  	}

        	  	@Override
        	  	public Mobile placeOrder(String mobileModels)  {
        	  		Mobile m=cs.placeOrder(mobileModels);
        	  		return m;
        	  	}

        	  	@Override
        	  	public Mobile displayOrder(int orderId) {
        	  		
        	  		Mobile m=cs.displayOrder(orderId);
        	  		return m;
        	  	}

        	  	@Override
        	  	public Long getCstmrDetails(Long mblNo,Customer c) {
        	  		cs.getCstmrDetails(mblNo, c);
        	  		return c.getCusCellNo();
        	  		
        	  	}
        	  	@Override
        	  	public String getMobileDetails(String s,Mobile m) throws MobileException
        	  	{
        	  		cs.getMobileDetails(s, m);
        	  		return m.getMobileModels();
        	  	}

}
