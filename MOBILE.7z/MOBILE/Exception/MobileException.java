package com.cg.mob.Exception;

public class MobileException extends Exception{

	public MobileException(String arg0) {
		super(arg0);
		System.out.println("INVALID" );
		
	}

}
