package com.cg.mob.entity;

import java.time.LocalDate;

public class Customer {

	private String cusName;
	private String cusAddres;
	private long cusCellNo;
	private int customerId;
	
	
	
	@Override
	public String toString() {
		return "Customer [customerId=" +customerId  +" cusName=" + cusName + ", cusAddres=" + cusAddres + ", cusCellNo=" + cusCellNo + 
			 "]";
	}
	public Customer(int customerId, String cusName, long cusCellNo, String cusAddres) {
	this.customerId=customerId;
	this.cusAddres=cusAddres;
	this.cusCellNo=cusCellNo;
	this.cusAddres=cusAddres;
	}
	public String getCusName() {
		return cusName;
	}
	
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusAddres() {
		return cusAddres;
	}
	public void setCusAddres(String cusAddres) {
		this.cusAddres = cusAddres;
	}
	public long getCusCellNo() {
		return cusCellNo;
	}
	public void setCusCellNo(long cusCellNo) {
		this.cusCellNo = cusCellNo;
	}
	

	
	
}
