package com.cg.mob.entity;

import java.time.LocalDate;
import java.util.Random;

public class Mobile {
private String mobileModels;

private int mobileprice;
private int orderId;
private int customerId;
private LocalDate purchasedate;

public Mobile()
{
	super();
}

public Mobile(int mobileprice, String mobileModels) {
	super();
this.mobileprice=mobileprice;
this.mobileModels=mobileModels;
}
@Override
public String toString() {
	return "Mobile [mobileModels=" + mobileModels + ", mobileprice=" + mobileprice + ", orderId=" + orderId
			+ ", customerId=" + customerId + ", purchasedate=" + purchasedate + "]";
}
public Mobile(int mobileprice, String mobileModels, int orderId, int customerId, LocalDate purchasedate) {
	super();
	
	this.mobileModels=mobileModels;
	this.mobileprice=mobileprice;
	this.orderId=orderId;
	this.customerId=customerId;
	this.purchasedate=purchasedate;
}

public String getMobileModels() {
	return mobileModels;
}
public void setMobileModels(String mobileModels) {
	this.mobileModels = mobileModels;
}

public int getMobileprice() {
	return mobileprice;
}

public void setMobileprice(int mobileprice) {
	this.mobileprice = mobileprice;
}

public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
}
