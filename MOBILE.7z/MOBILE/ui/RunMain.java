package com.cg.mob.ui;

import java.time.LocalDate;
import java.util.Scanner;


import com.cg.mob.Exception.MobileException;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.sevice.MobileService;
import com.cg.mob.sevice.MobileServiceImpl;

public class RunMain {
	static Scanner sc = null;
	
	static MobileService mobileservice=null;
	public static void main(String[] args) throws MobileException  {
		sc=new Scanner(System.in);
		 mobileservice=new MobileServiceImpl();
		int choice=0;
		System.out.println("1:To place Order");
		System.out.println("2:Display order with custmrid");
		System.out.println("3.to add mobile details");
		System.out.println("4.to add customer details");
		System.out.println("enter choice");
	    choice=sc.nextInt();
	    switch(choice) {
	    case 1:
	    	placeOrder();
	    	break;
	    case 2:
	    	displayOrder();
	    	break;
	    case 3:
	    	getMobileDetails();
	    	break;
	    case 4:
	    	addCstmrDetails();
	    	break;
	   default:
		   System.out.println("wrong choice");
	    	
	    }
		
	}
	private static void addCstmrDetails() {
		
		sc=new Scanner(System.in);
		System.out.println("enter name");
		String name=sc.nextLine();
		System.out.println("enter custmr id");
		int id=sc.nextInt();
		System.out.println("enter mobile no");
		Long mblNo=sc.nextLong();
		System.out.println("enter address");
		String address=sc.nextLine();
		Customer c=new Customer(id,name,mblNo,address);
		Long l=mobileservice.getCstmrDetails(mblNo,c);
		System.out.println("customer details added:"+l);
		
	}
	private static void getMobileDetails() throws MobileException {
		sc=new Scanner(System.in);
		System.out.println("enter new model u want to add");
		String mobileModels=sc.nextLine();
		System.out.println("enter price u want to add");
	int price=sc.nextInt();
		Mobile m=new Mobile(price,mobileModels);
		String s=mobileservice.getMobileDetails(mobileModels,m);
		System.out.println("mobile details added:"+mobileModels+""+m);
		
	}
	private static void displayOrder() {
		System.out.println("enter order id");
		sc=new Scanner(System.in);
		int orderId=sc.nextInt();
		Mobile m=mobileservice.displayOrder(orderId);
		System.out.println(m);
		
		
	}
	private static void placeOrder()  {
	sc=new Scanner(System.in);
	System.out.println("select which mobile you want");
	System.out.println("1.ASUS");
	System.out.println("2.iPhone");
	System.out.println("3.SONY");
	System.out.println("4.XIAMO");
	System.out.println("5.NOKIA");
	String mobileModels=sc.nextLine();
		Mobile m=mobileservice.placeOrder(mobileModels);
		
		String model=m.getMobileModels();
		int price=m.getMobileprice();
		System.out.println(m);
		System.out.println("enter your details to complete your order");
		System.out.println("enter name");
		String name=sc.nextLine();
		try {
			if (mobileservice.validateCstmrName(name)==true) {
				
				System.out.println("enter mobile number:");
				String mobNo = sc.nextLine();
				int cstmrid=101;
				String address="street1";
				try {
					if ((mobileservice.valiateCstmrCellNo(mobNo))==true) {
						Customer customer=new Customer(cstmrid,name,Long.parseLong(mobNo),address);
						
						Long l=mobileservice.getCstmrDetails(Long.parseLong(mobNo),customer);
						System.out.println("customer details added:"+l);
						int cstmrId=(int )(Math. random() * 100 + 1);
						int ordrId=(int )(Math. random() * 5000 + 1);
						System.out.println("order placed successfully "+"\n order id:"+ordrId);
						
						Mobile m2=new Mobile(price,model , ordrId, cstmrId, LocalDate.now());
						String s=mobileservice.getMobileDetails(mobileModels,m2);
						System.out.println("mobile details sucessfully added:"+s);
						System.out.println("enter order id ");
						{
						int orderId1=sc.nextInt();
						mobileservice.displayOrder(orderId1);
						System.out.println(m2);//
						
						}
						
						
						
						
		        		}
						
		
					
						
						
				
					else {
						throw new MobileException(mobNo);
					}
		}
				catch(MobileException me) {
					me.getStackTrace();
				}
		
	}
			else {
				throw new MobileException(name);
			}}
catch(MobileException me) {
	me.getStackTrace();
}
		

		
	}
	
}

