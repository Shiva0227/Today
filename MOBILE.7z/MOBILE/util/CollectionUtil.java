package com.cg.mob.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public class CollectionUtil {
	private static HashMap<String,Mobile> map1=new HashMap<String,Mobile>();
	static {
		map1.put("ASUS", new Mobile(18000,"ASUS"));
		map1.put( "iPhone", new Mobile(40000, "APPLE"));
		map1.put("SONY", new Mobile(19000,"SONY"));
		map1.put("XIAMO", new Mobile(16000,"XIAMO"));
		map1.put("NOKIA", new Mobile(25000,"NOKIA"));
		
	}
	private static HashMap<Integer,Mobile> map3=new HashMap<Integer,Mobile>();
	static {
		map3.put(5001, new Mobile(18000,"ASUS",5001,101,LocalDate.of(2019,Month.JANUARY,04)));
		map3.put(5002, new Mobile(18000,"iPhone",5002,102,LocalDate.of(2018,Month.AUGUST,01)));
		map3.put(5003, new Mobile(18000,"sony",5003,103,LocalDate.of(2010,Month.APRIL,02)));
		map3.put(5004, new Mobile(18000,"Nokia",5004,104,LocalDate.of(2016,Month.JULY,03)));
		map3.put(5005, new Mobile(18000,"Redmi",5005,105,LocalDate.of(2015,Month.OCTOBER,05)));
	}
	private static HashMap<Long,Customer> map2=new HashMap<Long,Customer>();
	static {
		map2.put(9090909090l, new Customer(101,"san",9090909090l,"street1"));
		map2.put(9090909091l, new Customer(102,"jhanu",9090909091l,"street2"));
		map2.put(9090909093l, new Customer(103,"rani",9090909093l,"street3"));
		map2.put(9090909094l, new Customer(104,"manu",9090909094l,"street4"));
		map2.put(9090909095l, new Customer(105,"kannan",9090909095l,"street5"));
	}
	public static Mobile placeOrder(String mobileModels) {
		return map1.get(mobileModels);
	}
public static Mobile displayOrder(int OrderId) {
	return map3.get(OrderId);
}
public static void getCstmrDetails(Long mblNo,Customer c){
	map2.put(mblNo, c);
	
}
public static void getMobileDetails(String model,Mobile m){
	map1.put(model, m);
	
}
}

