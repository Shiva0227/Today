package Ex1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
public class Mainn {
		public static void main(String args[]) throws IOException, InterruptedException {
		BufferedReader in = null;
		BufferedWriter out = null;
		Runnable worker = null;
		in = new BufferedReader(new FileReader("source.txt"));
		Executor executor = Executors.newSingleThreadExecutor();
		worker = new Multithread(in,out);
		executor.execute(worker);

}
}

