package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployservceInterface {

			void storeIntoMap(Employee e);
			void displayDetails();
			String getScheme(int id);
}

