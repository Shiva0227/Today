package com.cg.eis.service;

import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeDAO;

public  class Employeeservice implements EmployservceInterface {
	
	Scanner input = new Scanner(System.in);
	EmployeDAO empDAO=new EmployeDAO();
	Employee emp = new Employee();
	public void storeEmployee(Employee e)
 {
		empDAO.storeIntoMap(e);
		}
public void displayDetails()
{
System.out.println("enter emp id: ");
int id = input.nextInt();
 emp =  empDAO.getFromMap(id);
 
 System.out.println(emp);
}
public String getScheme(int id)
{
	
	Employee e=empDAO.getSchemefromMap(id);
	
	int Salary=0;
	if(Salary>5000&&Salary<20000){
		e.setDesignation("System Associate");
		e.setInsurescheme("Scheme C");
		}

	else if(Salary>=20000&&Salary<40000)
	{
		e.setDesignation("Programmer");
		e.setInsurescheme("Scheme B");

	}
	else if(Salary>=40000)
	{
		e.setDesignation("Manager");
		e.setInsurescheme("Scheme A");
	}
	else if(Salary<5000)
	{
		e.setDesignation("Clerk");
		e.setInsurescheme("No scheme");
	}
	else
		System.out.println("Invalid ");

	return e.getInsurescheme();
	}
public void storeIntoMap(Employee e) {
	// TODO Auto-generated method stub
	
}

	}


