package com.cg.eis.dao;
import java.util.Map;

import com.cg.eis.bean.Employee;



public interface EmployeeDAOInterface {
	
     void storeIntoMap(Employee e);
     Map<Integer,Employee>displayDetailsfromMap();	
     Employee getSchemefromMap(int id);
    
}
