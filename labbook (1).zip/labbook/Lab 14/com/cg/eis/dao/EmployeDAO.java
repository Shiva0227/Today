package com.cg.eis.dao;

import java.util.Map;
import java.util.HashMap;


import com.cg.eis.bean.Employee;

	public class EmployeDAO implements EmployeeDAOInterface {
		
		Employee emp = new Employee();
		
		static Map<Integer,Employee> hm= new HashMap<Integer,Employee>();
		
	public void storeIntoMap(Employee e)
	{
		hm.put(e.getId(),e);
		System.out.println(hm);
	}

	public Map<Integer, Employee> displaydetailsfromMap() {
		
		return hm;
		
	}

	public Employee getschemefromMap(int id) {
		
		return hm.get(id);
	}
	
	public Employee getFromMap(int id) {
		// TODO Auto-generated method stub
		return hm.get(id);
	}

	public Map<Integer, Employee> displayDetailsfromMap() {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee getSchemefromMap(int id) {
		// TODO Auto-generated method stub
		return null;
		
		
	}
}




	

