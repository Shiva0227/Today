package com.cg.eis.pl;

import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Employeeservice;


public class Main {

public static void main(String args[])

{

	String ch=null;
	boolean bool = true;
	Employee e=new Employee();
	Employeeservice employeeService=new Employeeservice();
while(bool)
{
	System.out.println("Enter your choice");
	Scanner sc=new Scanner(System.in);
	System.out.println("Store val=1"+"\nDisplay val=2"+"\nSearch id=3");
	int n=sc.nextInt();
		switch(n)
		{
		case 1:
		{
			System.out.println("Enter your Name");
			String Name=sc.next();
			e.setName(Name);
			System.out.println("Enter Eid");
			int id=sc.nextInt();
			e.setId(id);
			System.out.println("Enter Salary");
			int sal=sc.nextInt();
			e.setSalary(sal);
			/*System.out.println("Enter designation");
			String des = ac.next();
			e.setDesignation(des);*/
			employeeService.storeEmployee(e);
			break;
		}
		case 2:
		{
			employeeService.displayDetails();
			/*Map<Integer,Employee>hm=
			System.out.println(hm);*/
			break;
			}
		
		
	   case 3:
	  {
		  System.out.println("Enter ID=");
		  int id=sc.nextInt();
		 // e.getInsurescheme(int id);

		  break;
		  /*System.out.println("Name of employee"+e.getName());
		  System.out.println("Scheme"+e.getInsurescheme());
		  break;*/
	  }
      
	  case 0: {bool = false; break;}
	 
		
	}
		
		

	}}}
		
			


