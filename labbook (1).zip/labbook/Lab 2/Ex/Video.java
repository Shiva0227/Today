package Ex;


public class Video extends MediaItem {
	private String director;
	private String genre;
	private int year_published;
	
	public Video(int id,String title,int num_of_Copies,int year_published,int runtime,String director, String genre)
	{
		super(id,title,num_of_Copies,runtime);
		this.year_published=year_published;
		 this.director=director;
		 this.genre=genre;
	} public String getDirector()
	{
		return director;
	}
	public void setDirector(String director)
	{
		this.director=director;
	}
	public String getGenre()
	{
		return genre;
	}
	public void setGenre(String genre)
	{
		this.genre=genre;
	}
	public int getYear_published()
	{
		return year_published;
	}
	public void setYear_published(int year_published)
	{
		this.year_published=year_published;
	}
	public void checkIn()
	{
		System.out.println("Videos has CheckIn");
	}
	public void checkOut()
	{
		System.out.println("Videos has CheckOut");
	}
	public void addItem(int n)
	{
System.out.println(n+"s are Added");			
	}
	public void removeItem(int n)
	{
		System.out.println(n+"Videos are Removed");
	}
	public String toString()
	{
		return super.toString()+" "+year_published;
	}

}
