package Ex;



public class WrittenItem extends Item {
	
	private String author;
	public WrittenItem(int id,String title,int number_of_Copies,String author)
	{
		super(id,title,number_of_Copies);
		this.author=author;
		}
	public String getAuthor()
	{
		return author;
	}
	public void setAuthor(String author)
	{
		this.author=author;
	}
	public int getId()
	{
		return super.id;
		}
	public void setId(int id)
	{
		super.id=id;
	}
	public String getTitle()
	{
		return super.title;
	}
	public void setTitle(String title)
	{
		super.title=title;	
	}
	public int getNumberOfCopies()
		{
	return super.num_of_Copies;
		}
	public void setNumberOfCopies()
	{
		super.num_of_Copies=num_of_Copies;	
	}
	public String toString()
	{
	return id+" "+title+" "+num_of_Copies+" "+author; 
	}
	public void checkIn()
	{
		System.out.println("Written Item Has CheckIn");	
	}
	public void checkOut()
	{
	System.out.println("Written Item Has CheckOut");
	}
	public void addItem(int n)
	{
		System.out.println("Written Items are Added");			
	}
	public void removeItem(int n)
	{
	System.out.println("Written Items are Removed");
}
}
