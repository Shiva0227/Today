package Ex;


import java.util.*;
public class Mainlib {
	public static void main(String args[])
	{
		System.out.println("1.BOOK 2.JOURNAL PAPER 3.VIDEOS 4.CDs");
		System.out.println("Enter your choice");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		switch(a)
		{
		case 1:
			Item i=new Book(1,"Karnan book",5,"Vyasa");
			System.out.println(i.toString());
			i.checkIn();
			i.checkOut();
			i.addItem(50);
			i.removeItem(8);
			break;
		case 2:
					Item j=new Journelpaper(1,"Karna ",100,"Vyasa",2000);
					System.out.println(j.toString());
					j.checkIn();
					j.checkOut();
					j.addItem(200);
					j.removeItem(10);
					break;
		case 3:
			Item k=new Video(1,"Karna video",10,50,2019,"study","Vyasa");
			System.out.println(k.toString());
			k.checkIn();
			k.checkOut();
			k.addItem(10);
			k.removeItem(4);
			break;
		case 4:
			CD n=new CD(6,"Karna  CD",8,50,"abc","epic");
			n.checkIn();
			n.checkOut();
			n.addItem(20);
			n.removeItem(0);
			break;
			default:
				break;
		}
		
		sc.close();
	}

}
