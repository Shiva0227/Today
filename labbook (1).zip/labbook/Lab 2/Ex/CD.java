package Ex;



public class CD extends MediaItem {
	private String artist;
	private String genre;
	public CD(int id,String title,int num_of_Copies,int runtime,String artist, String genre)
	{
		super(id,title,num_of_Copies,runtime);
		 this.setArtist(artist);
		 this.setGenre(genre);
	} public String getArtist()
	{
		return artist;
	}
	public void setArtist(String artist)
	{
		this.artist=artist;
	}
	public String getGenre()
	{
		return genre;
	}
	public void setGenre(String genre)
	{
		this.genre=genre;
	}
	
	public void checkIn()
	{
		System.out.println("CDs have CheckIn");
	}
	public void checkOut()
	{
		System.out.println("CDs have CheckOut");
	}
	public void addItem(int n)
	{
System.out.println(n+"CDs are Added");			
	}
	public void removeItem(int n)
	{
		System.out.println(n+"CDs are Removed");
	}
	public String toString()
	{
		return super.toString()+" "+artist+" "+genre;
	}


}
