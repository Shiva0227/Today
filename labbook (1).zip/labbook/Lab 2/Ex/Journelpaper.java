package Ex;

public class Journelpaper extends WrittenItem {
	private int year_published;
	public Journelpaper(int id,String title,int number_of_Copies,String author,int year_published)
	{
		super(id,title,number_of_Copies,author);
		this.year_published=year_published;
	}
	public int getYear_published()
	{
		return year_published;
	}
	public void setYear_published(int year_published)
	{
		this.year_published=year_published;
	}
	public void checkIn()
	{
		System.out.println("Journels has CheckIn");
	}
	public void checkOut()
	{
		System.out.println("Journels has CheckOut");
	}
	public void addItem(int n)
	{
		System.out.println(n+"Journels are Added");			
	}
	public void removeItem(int n)
	{
		System.out.println(n+"Journels are Removed");
	}
	public String toString()
	{
		return super.toString()+" "+year_published;
	}

}



