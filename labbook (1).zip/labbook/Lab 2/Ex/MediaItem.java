package Ex;



public class MediaItem extends Item {
	private int runtime;
	public MediaItem(int id,String title,int number_of_Copies,int runtime)
	{
		super(id,title,number_of_Copies);
		this.runtime=runtime;
		}
	public int getRuntime()
	{
		return runtime;
	}
	public int setRuntime(int runtime)
	{
		 return this.runtime=runtime;
	}
	public int getId()
	{
		return super.id;
		}
	public void setId(int id)
	{
		super.id=id;
	}
public String getTitle()
{
return super.title;
}
public void setTitle(String title)
{
super.title=title;	
}
public int getNumberOfCopies()
{
	return super.num_of_Copies;
}
public void setNumOfCopies()
{
super.num_of_Copies=num_of_Copies;	
}
public String toString()
{
	return id+" "+title+" "+num_of_Copies+" "+runtime; 
}
public void checkIn()
{
System.out.println("Media Item Has CheckIn");	
}
public void checkOut()
{
	System.out.println("Media Item Has CheckOut");
}
public void addItem(int n)
{
System.out.println("Media Items are Added");			
}
public void removeItem(int n)
{
	System.out.println("Media Items are Removed");
}

	
}
