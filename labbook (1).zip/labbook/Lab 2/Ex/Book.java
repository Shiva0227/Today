package Ex;


public class Book extends WrittenItem {
	
	public Book(int id,String title,int num_of_Copies,String author)
	{
		super(id,title,num_of_Copies,author);
	}
		public String toString()
		{
			return super.toString();
		}
		
		public void checkIn()
		{
			System.out.println("Books has CheckIn");
		}
		public void checkOut()
		{
			System.out.println("Book has CheckOut");
		}
		public void addItem(int n)
		{
System.out.println(n+"Books are Added");			
		}
		public void removeItem(int n)
		{
			System.out.println(n+"Books are Removed");
		}
	}


