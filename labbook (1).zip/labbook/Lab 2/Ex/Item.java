package Ex;


public abstract class Item {
	int id;
	String title;
	int num_of_Copies;
	public Item(int id,String title,int number_of_Copies) {
		this.id=id;
		this.title=title;
		this.num_of_Copies=number_of_Copies;
		
}
public abstract void checkIn();
public abstract void checkOut();
public abstract void addItem(int n);
public abstract void removeItem(int n);
	

}
