package Ex5;
import java.util.Scanner;

public class Stringval {

	public static boolean Stringval(String str) {
		int value = -1;
		boolean b= false;
		for (char ch : str.toLowerCase().toCharArray()) {
			
			if (((ch - 'a') + 1) >= value) {
				b = true;
				value = (ch - 'a') + 1;} 
			else {
				b = false;			
				break;
				}
			}
		return b;
		}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string to check if it is positive or not: ");
		System.out.println("The Given string is " + (Stringval(input.nextLine()) == true ? "Positive." : "Negative."));
		input.close();

}

}
