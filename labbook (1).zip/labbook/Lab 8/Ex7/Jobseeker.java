package Ex7;

import java.util.Scanner;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

public class Jobseeker
{
	public static boolean validate(String userName)
{
		boolean valid = false;
		Pattern pattern = Pattern.compile("[^a-z0-9_]", Pattern.CASE_INSENSITIVE);
		Matcher match = pattern.matcher(userName);
		
		if (userName.length() >= 12&& userName.substring(userName.length() - 4).equals("_job")&& match.find() != true)
			valid = true;
		else
			valid = false;
		
		return valid;
		}
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String userName = input.nextLine(); 
		input.close();
		System.out.println(validate(userName));

            }}
