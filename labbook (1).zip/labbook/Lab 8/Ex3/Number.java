package Ex3;

import java.io.BufferedReader;

import java.io.FileReader;

import java.io.IOException;

public class Number

{
	public static void main(String[] args)
	{
		int lineNumer = 0;
		int charCnt = 0;
		int wrdCnt = 0;
		boolean b;

	BufferedReader reader;

	try
	{
		reader = new BufferedReader(new FileReader("Read.txt"));
		String line = reader.readLine();

		while (line != null)

	{
			b = true;
			++lineNumer;
			System.out.print( lineNumer + ": ");
			System.out.print(line);

	for (char ch : line.toCharArray())

		{
		++charCnt;
		if (ch == 0)
			b = true;

		if (b==true) 
			{
			++wrdCnt;
			b = false;
			}

	}

		System.out.println(" -> Character count: " + charCnt);
		line = reader.readLine();
		charCnt = 0;
		}

		System.out.println("\nTotal Word count: " + wrdCnt);
		reader.close();
			}
	catch (IOException e)
	{
			e.printStackTrace();
			}
	}}
