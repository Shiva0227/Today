package Ex2;

import java.util.Scanner;
import java.io.*;

public class Readisply
{
    public static void main(String[] input)
    {
        String file;
        BufferedReader Reader;
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter File Name:");
        file = scan.nextLine();
        String line = null;
        int linenum=0;
        try
        {
         
            /*FileReader Reader = new FileReader(file);*/
            Reader = new BufferedReader(new FileReader(file));
            String line1= Reader.readLine();
            while((line1!=null))
            {
            	++linenum;
            	System.out.print( + linenum + ":");
            	System.out.println(line1);
            	
               // System.out.println(line1);
                line1=Reader.readLine();
            }
         
            Reader.close();
        }
        catch(IOException ex)
        {
            System.out.println("Error file '" + file + "'");
        }
    }
}
