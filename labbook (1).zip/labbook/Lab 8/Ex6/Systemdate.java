package Ex6;

import java.time.*;

import java.util.*;

public class Systemdate

{

	public static void calculateDuration(LocalDate EntredDate)

	{

		LocalDate currDate = LocalDate.now();

		// Gets duration between two dates
		Period duration = Period.between(currDate, EntredDate);
		System.out.printf("Difference is %d years, %d months and %d days",duration.getYears(), duration.getMonths(), duration.getDays());
}
	public static void main(String[] args)
	{

		int date =22, month = 07, year = 1996;
		/*Scanner input = new Scanner(System.in);
		System.out.println("Enter Date: ");
		date = input.nextInt();
		System.out.println("Enter Month: ");
		month = input.nextInt();
		System.out.println("Enter year: ");
		year = input.nextInt();*/

		// Pass values to create date object
		LocalDate EntredDate = LocalDate.of(year, month, date);
		calculateDuration(EntredDate);
		//input.close();

	}

}