package Ex2;
import java.util.*;

public class Charctrcount
{
	public HashMap<Character, Integer> calculateCount()
	{  
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter a string:");
		String str = input.nextLine();
		input.close();

		char[] ar = str.toCharArray();
		
		HashMap<Character, Integer> hashMap = new HashMap<Character, Integer>();
		char compare = '!'; //Lower ASCII value than alphabets

		Arrays.sort(ar); //Sort array

		//Print character occurrence count once
		for(int i = 0; i < ar.length; i++)
		{
			if(compare < ar[i])
			{ 
				hashMap.put(ar[i], getCount(ar, ar[i]));
				compare = ar[i];
			}
		}		
		return hashMap;
	}

	//Get character occurrence count
	public static int getCount(char[] ar,char c)
	{
		int count = 0;
		for(char ch : ar)
		{
			if(ch == c)
			{
				count++;
			}
		}
		return count;
	}
}
