package Ex2;
public class Main 
{
	public static void main(String[] args)
	{
		Charctrcount c = new  Charctrcount();
		System.out.println(c.calculateCount());
	}
}
