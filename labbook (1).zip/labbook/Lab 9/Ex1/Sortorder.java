package Ex1;

import java.util.*;

public class Sortorder {
	public List<Integer> converToList(java.util.HashMap<String, Integer> hashMap) {
		ArrayList<Integer> arrayList = new ArrayList<Integer>();
		arrayList.addAll(hashMap.values());

		Collections.sort(arrayList);

		return arrayList;
	}

	public void getHashMap() {
		String key;
		int value;

		HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
		Scanner input = new Scanner(System.in);

		System.out.println("Enter Number of HashMap sets you want to create:");
		int n = input.nextInt();

		for (int i = 0; i < n; i++) {
			System.out.println("Enter Key (String):");
			key = input.next();

			System.out.println("Enter Values (Integer):");
			value = input.nextInt();

			hashMap.put(key, value);
		}
		input.close();

		System.out.println(converToList(hashMap));
	}
}
