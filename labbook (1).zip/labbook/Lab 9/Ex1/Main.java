package Ex1;
public class Main 
{
	public static void main(String[] args)
	{
		Sortorder s = new Sortorder();
		s.getHashMap();
	}
}
