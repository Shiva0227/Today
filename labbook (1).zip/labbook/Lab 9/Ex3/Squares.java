package Ex3;
import java.util.*;

public class Squares 
{
	public HashMap<Integer, Integer> calculateSquare(int[] ar)
	{
		HashMap <Integer, Integer> hashMap = new HashMap<>();
		
		for(int n : ar)
		{
			hashMap.put(n, n*n);
		}
		
		return hashMap;
	}
	
	public void getArray()
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter Array Count:");
		int n = input.nextInt();
		int[] ar = new int[n];
		
		System.out.println("Enter Array Values:");
		for(int i = 0; i < n; i++)
		{
			ar[i] = input.nextInt();
		}
		
		input.close();
		System.out.println(calculateSquare(ar));
	}
}
