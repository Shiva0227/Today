package Ex3;

public class Main 
{
	public static void main(String[] args)
	{
		Squares s = new Squares();
		s.getArray();
	}
}
