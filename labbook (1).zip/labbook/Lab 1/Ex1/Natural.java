public class Natural 
{

    
 public static void main(String []args)
 {
       
  Sum s=new Sum();
        
  s.calculateSum(20);
       
        
     
 }
    
}
   
  class Sum
{
         
     
     
  public void calculateSum(int n)
      
      
 {
           
   int sum=0;
          
   for(int i=1;i<=n;i++)
          
    {
              
      if(i%3==0||i%5==0)
              
                
                 
       sum+=i; 
          }
           
   System.out.println(sum);
   
   }
    
 
}


