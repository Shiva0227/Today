package Ex3;

public class Increase {

	public static void main(String[] args) {
		
		Increase s=new Increase();
		s.checkNumber(1344968);
		
		}
	 
	public void checkNumber(int n)
		{
		 int bignum=10;
		 boolean b=false;
	
		while(n>0)
		{
			 int digit=n%10;
			 n=n/10;
			 if (digit<=bignum)
			 {
				 bignum=digit;
				 b=true;
			 }
			 else
			 {
				 b=false;
				 break;
			 }
		}
		System.out.println(b);
			 
		}
		
		}
	
	
	

