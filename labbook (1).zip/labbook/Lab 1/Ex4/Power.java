package Ex4;

public class Power {

	public static void main(String[] args) {
		Power p=new Power();
		p.checkNumber(8);
		
	}
	public void checkNumber(int n)
	{
		int pow=1;
		boolean b=false;
		if(n%2==0)
		{
			for(int i=1;i<=n/2;i++)
			{
				pow*=2;
				if(pow==n)
				{
					b=true;
					break;
				}
				else
				{
					b=false;
									}
			}
		
		}
		
		System.out.println(b);
	}
	

}
