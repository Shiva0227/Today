package Ex1;;

public class Naturalsq 
{

     
 public static void main(String []args)
 {
       
   Sum s=new Sum();
        
   s.calculateDifference(5);
       
        
    
  }
     
  }
     
 class Sum
 {
         
     
      
  public void calculateDifference(int n)
      
      
 {
           
  int sumsq=0,sqsum=0,diff=0;
          
  for(int i=1;i<=n;i++)
          
 {
              
             
  sumsq+=i*i; 
             
  sqsum+=i;
             
  diff=sumsq-sqsum;
          
 }
          
           
 System.out.println(diff);
      
  }
    
 
}
