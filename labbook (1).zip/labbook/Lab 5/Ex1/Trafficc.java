package Ex1;
import java.util.Scanner;


public class Trafficc{ 
	
	
	public void fav(int s)
	  {
		   
	   switch(s) {
	      case 1:
	        System.out.println(" Stop");
	        break;
	      case 2:
	         System.out.println("Ready");
	        break;
	      case 3:
	        System.out.println(" Go");
	        break;
	       default:
	          System.out.println("invalid");
	          break;
	    }
	  }
	 public static void main(String[] args) {
	   
		//  String str = null ;
		 System.out.println("1.red\n2.yellow\n3.green");
		 Scanner in=new Scanner(System.in);
		 System.out.println("enter= ");
		 int s=in.nextInt();
		  Trafficc t=new Trafficc();
		  t.fav(s);
		 
		  //Traffic e=new Traffic(Light.valueOf(str));
		  //e.fav();
		  }
	}