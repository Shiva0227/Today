package Ex5;

import java.util.Scanner;

public class Age {
   
   public static void main(String[] args) {
		
				Age a=new Age();
				a.val();
	}

   public void val()
   {
	     int age;
	    Scanner sc = new Scanner(System.in);
	     System.out.println("Enter the age=");
	     age=sc.nextInt();
	     try {
	    	 if(age<=15) {
	    		 throw new Exception();
	    		 }
	    	 else
	    		 System.out.println("Person has Valid Age");
	     } 
	    catch(Exception e)
	    {
	    	System.out.println("Person has Invalid age");
	    }
	    
	    		 
	     	     
   }
}
