package Ex3;

import java.util.Scanner;

public class Prime {

	private Scanner sc;


	public static void main(String[]args)
	{
		Prime p=new Prime();
		p.primeval();
	}
		
		
	public void primeval()
	{
		
		int n;
		sc = new Scanner(System.in);
		System.out.println("enter th number");
		n=sc.nextInt();
		boolean TorF = false;
		 for(int i =2; i <= n; i++)
		    {
		       for(int j =2; j <= i; j++)
		        {  
		         if(i == j) TorF=true;
		    	   
		         else if(i%j == 0)
		            {
		            	TorF=false;
		                break;
		            }
		            else 
		            TorF=true;
		            }
		          if(TorF==true)
		        {
		        	System.out.println("prime "+i);
		       
		        }
		         
		    }
		 
		    
		}  }
		 
