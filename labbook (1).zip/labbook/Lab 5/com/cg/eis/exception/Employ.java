package com.cg.eis.exception;

import java.util.Scanner;

public class Employ extends EmployeeExceptn {
		public static void main(String[]args)
		{
			EmployeeExceptn v=new EmployeeExceptn();
			v.sub();
		
		
}}
