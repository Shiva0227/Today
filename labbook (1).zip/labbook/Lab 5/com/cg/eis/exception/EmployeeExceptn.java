package com.cg.eis.exception;

import java.util.Scanner;

public class EmployeeExceptn extends Exception {
	
	
	public void sub() {
		
			
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter salary");
		int g=sc.nextInt();
		try
		{
			if(g<3000)
			{
				throw new EmployeeExceptn();
			}
			else
			{
				System.out.println("Valid salary");
			}
			
		}
		
		catch(Exception e)
		{
			System.out.println("Invalid salary");
		}
	
	/* finally {
		 System.out.println("Your salary value "+g);
	 }*/
		}

		
	} 
	

