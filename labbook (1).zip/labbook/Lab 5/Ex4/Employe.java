package Ex4;

import java.util.Scanner;

/*class value extends Exception
 {		
	   super(e);
}*/
public class Employe {

	public static void main(String[] args) {
		Employe e=new Employe();
		e.imp();
		
	}
  
	
	public void imp()
	{
		String Fname;
		String Sname;
		 Scanner sc = new Scanner(System.in);
	     System.out.println("Enter the Firstname=");
	     Fname=sc.nextLine();
	     System.out.println("Enter the Secondname=");
	     Sname=sc.nextLine();
		
		try {
	    	 if(Fname.isEmpty()) {
	    		 throw new Exception();
	    		 }
	    	 else
	    		 System.out.println("Name valid");
	     } 
	    catch(Exception e)
	    {
	    	System.out.println("Name is blank");
	    }
	}
}