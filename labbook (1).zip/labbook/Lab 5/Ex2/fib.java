package Ex2;

public class fib {
 
		public static void main(String args[])  
		{  
			 fib b=new fib();
			 b.ser();
			// fib b1=new fib();
			System.out.println("\n\nRecursive value\t\t"+b.recur(5));
		
				 }  
		

	public void ser() 
	 {
	 int a=1,b=2,c = 0,i,count=9;    
	
    for(i=3;i<count;++i)
	 {    
	  c=a+b;    
	  a=b;    
	  b=c;    
	   
	 }    
    System.out.print("\nNon recursive value\t"+c); 
	  }
	public int recur(int n)
	{
		if(n==1)
			return 1;
		if (n==2)
			 return 2;
		else
			return (recur(n-1)+recur(n-2));
	}
	 
	       
		}  



