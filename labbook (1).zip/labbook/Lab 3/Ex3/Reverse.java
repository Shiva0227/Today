package Ex3;
public class Reverse
{
	public static void main(String[] args) 
	{
	    int a []  = {4,1,6,2,8};
		getsorted(a);
	}
	
	
	public static void sortArray(int a [] )
	{
	  int temp = 0;
	  for(int i =0; i< a.length; i++)
	  {
	      for( int j = i+1; j< a.length; j++)
	      {
	          if(a[i] > a[j])
	          {
	              temp = a[i];
	              a[i] = a[j];
	              a[j] = temp;
	          }
	      }
	  }
	  
	  for(int num : a)
	  {
	      if(num != a[a.length-1])
	      System.out.print(num + ", ");
	      else 
	      System.out.print(num);
	  }
	  System.out.println();
	}
	
	public static void getsorted(int[] a)
	{
	    int[] aray= new int[a.length];
	    int j = a.length - 1;
	    
	    for(int i = 0; i < a.length ; i++)
	    {
	        aray[i] = a[j];
	        j--;
	    }
	    
	    for(int i : aray)
	    {
	        System.out.print(i + " ");
	    }
	    System.out.println();
	    sortArray(a);
	}
}
