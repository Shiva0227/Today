package Ex1;

public class Integer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a={2,6,3,1,5,4};	
		Integer s=new Integer();
		s.getSecondSmallest(a);
	 
	}
	public void getSecondSmallest(int[]a)
	{
	  int temp=0;
	  for(int i=0;i<a.length;i++)
	  {
		  for(int j=i+1;j<a.length;j++)
		  {
			  if(a[i]>a[j])
			  {
				  temp=a[i];
				  a[i]=a[j];
				  a[j]=temp;
			  }
		  }
	  }
	  System.out.println(a[1]);
	}

}
