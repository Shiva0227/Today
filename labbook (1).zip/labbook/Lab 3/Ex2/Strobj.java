package Ex2;

public class Strobj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String []a={"Hi","vanakam","hello"};	
		//Strobj s=new Strobj();
	sort(a);
	 
	}
	public static void sort(String[] a)
	{
	  String temp;
	  for(int i=0;i<a.length;i++)
	  {
		  for(int j=i+1;j<a.length;j++)
		  {
			  if((a[i]).compareTo(a[j])>0)
			  {
				  temp=a[i];
				  a[i]=a[j];
				  a[j]=temp;
			  }
		  }
	  }
	  //System.out.println();
	  
	   printArray(a);
	}

	public static void printArray(String[] a)
	{
	   
	    int l = a.length;
	    if(l % 2 == 0)
	    l = a.length / 2;
	    else
	    l = (a.length / 2) + 1;
	    
	    for(int i = 0; i < a.length; i++)
	    {
	        if(i < l)
	        System.out.println(a[i].toUpperCase());
	        else
	        System.out.println(a[i].toLowerCase());
	    }
	    
	}
}
