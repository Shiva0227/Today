package Ex4;
import java.util.Arrays;

public class Count
{
	public static void main(String[] args) 
	{
	    char[] ar = {'n','v','e','a','a','e','v','n','n','a','v','a','e'};
	    sortArray(ar);
	}
	
	
	public static void sortArray(char[] ar)
	{
	    char compare = '!';
	    
	    Arrays.sort(ar);
	    
	    for(int i = 0; i < ar.length; i++)
	    {
	     if(compare < ar[i])
	     {
	         System.out.println(ar[i] + " " + getCount(ar, ar[i]));
	         compare = ar[i];
	     }
	    }
	}
	
    public static int getCount(char[] ar,char c)
	{
	    int count = 0;
	    for(char ch : ar)
	    {
	        if(ch == c)
	        {
	            count++;
	        }
	    }
	    return count;
	}
}
