package Ex5;

import java.util.Scanner;

import java.util.stream.IntStream;

public class Factorial {
	int fact(int n) {
		IntStream stream = IntStream.rangeClosed(1, n);
		int str = stream.reduce(1, (a,b)->a*b);
		return str;
}}
class Main{
	public static void main(String args[]) {
		int n;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the no");
		n = scan.nextInt();
		int stream1;
		Factorial f = new Factorial();
		stream1 = f.fact(n);
		System.out.println("factorial is=" +stream1);
}}

