package Ex2;

import java.util.function.Function;

/*Write a method that uses lambda expression to format a given string, where a space
is inserted between each character of string. For ex., if input is �CG�, then expected output is 
�C G�.*/

public class Strngformt {
	public static void main(String[]args)
	{
	/*Function<String,String> val=(str) ->str.replace("", " ").trim();
	 System.out.println(val.apply("Awesme"));
		*/
		
		Function<String,StringBuffer> val=(str)->
		{
			char[] c=str.toCharArray();
			StringBuffer s1=new StringBuffer();
			for(int i=0;i<c.length;i++)
				s1.append(c[i]+" ");
			return s1;
			
		};
	System.out.println(val.apply("CG"));
	
	}}