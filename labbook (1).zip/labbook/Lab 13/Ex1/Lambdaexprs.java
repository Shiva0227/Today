package Ex1;

import java.util.function.BiFunction;

public class Lambdaexprs {

	public static void main(String[] args) {					//typecastng
		BiFunction<Integer, Integer,Integer> powerr = (x, y) ->(int)Math.pow((double)x,(double)y);
		  System.out.println("Value= " +powerr.apply(10, 2)); 
	}

}
