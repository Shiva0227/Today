package Ex1;
import java.io.BufferedReader;
import java.io.BufferedWriter;
public class FileProgram {
/* extends CopyDataThread{
public File(BufferedReader in, BufferedWriter out) {
		super(in, out);
		
	}*/

public static void main(String[]args)
		{
			
	
		
	     CopyDataThread obj=new CopyDataThread();
	     Thread t1=new Thread (obj);
	     t1.start();
	     
	}}