package com.cg.emp.entity;

import java.time.LocalDate;
import java.util.Comparator;

public class Employee implements Comparator{
private int empId;
private String empName;
private float empSal;
private LocalDate empDOJ;
public Employee()
{
	super();
}
public Employee(int empId, String empName, float empSal, LocalDate empDOJ) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSal = empSal;
	this.empDOJ = empDOJ;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDOJ=" + empDOJ + "]";
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public float getEmpSal() {
	return empSal;
}
public void setEmpSal(float empSal) {
	this.empSal = empSal;
}
public LocalDate getEmpDOJ() {
	return empDOJ;
}
public void setEmpDOJ(LocalDate empDOJ) {
	this.empDOJ = empDOJ;
}
public static Comparator<Employee> getcompname()
{
	Comparator<Employee> comp=new Comparator<Employee>() {@Override
public int compare(Employee o1, Employee o2) {
	// TODO Auto-generated method stub
	return  o1.empName.compareTo(o2.empName);
}
	};
	return comp;
}
@Override
public int compare(Object o1, Object o2) {
	// TODO Auto-generated method stub
	return 0;
}
}





