package com.cg.emp.ui;

import java.security.KeyStore.Entry;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;
import com.cg.emp.util.CollectionUtil;


public class RunMain {
	static Scanner sc=null;
	static EmployeeService empservice=null;
public static void main(String[] args) {
	
	sc=new Scanner(System.in);
	empservice=new EmployeeServiceImpl();
	int choice=0;
		
		System.out.println("what do u want to do?");
		System.out.println("1.add emp\t2:fetch all emp\n");
		System.out.println("3.delet emp\t4:search emp by id\n");
		System.out.println("5 search by name\t6:update emp");
		System.out.println("7.EXIT\n");
		System.out.println("enter ur choice");
		choice=sc.nextInt();
		switch (choice) {
		case 1:
			addEmployee();
		break;
         case 2:
        	
       fetchAllDetails();
			break;
         case 3:
        	 deleteEmp();
	         break;
         case 4:
	getEmpById();
	         break;
               case 5:
            	  sortByName();
	          break;
           case 6:
        	   updateEmp();
        	  
	            break;
             case 7:
	System.exit(0);
             break;
	

		default:
			break;	
			
		}
	}

private static void addEmployee() {
	System.out.println("enter emp id:");
		String eid=sc.next();
		try
		{
		if(empservice. validateEid(eid)==true)
		{
				             System.out.println("enter the employee name");
			                String name=	sc.next();
		                    	try
		                    	{
		                  	
				                   if(empservice.validateName(name)==true)
				                   {
				                	  
					                      System.out.println("enter emp sal:");
					                 String sl=sc.next(); //validate sal//
                                     try {
					                  if(   empservice.validateSal(sl)==true)
					                  {
				                    	System.out.println("enter  joining year");
				                int year=sc.nextInt();
				            	System.out.println("enter month");
				             int month=sc.nextInt();
				         	System.out.println("enter date");
				                int dayOfMonth=sc.nextInt();
				                 			Employee employee=new Employee(Integer.parseInt(eid), name,Float.parseFloat(sl) , LocalDate.of(year, Month.of(month), dayOfMonth));
						   					
						   					int empId=empservice.addEmployee(Integer.parseInt(eid),employee);
						   					System.out.println("New employee added:"+employee);
						   					System.out.println("employee added"+""+empId);
					                  }
					                          else
					                        		{
					                        			
					                        				throw new EmployeeException(sl);
					                        		}}
					                        			catch (EmployeeException e) {
					                        				
					                        				e.getStackTrace();
					                        			}}
					                        			else
					                        			{

					                        				throw new EmployeeException(name);}}
					                        			catch (EmployeeException e) {
					                        				
					                        				e.getStackTrace();
					                 				
					                        			}}
                                                      else
	                        			      {

	                        				throw new EmployeeException(eid);
	                        				}}
	                        			catch (EmployeeException e) {
	                        				
	                        				e.getStackTrace();
	                 				
	                 		           	}
		                                }
					                    	
					           		
							                 			
							                 		
							                 			
					
			  
	
	    	
			public static void fetchAllDetails()
			 {
				 HashMap<Integer, Employee> hs=empservice.fetchAllEmp();
				 Set set = hs.entrySet();
			      Iterator iterator = set.iterator();
			      while(iterator.hasNext()) {
			         Map.Entry e = (Map.Entry)iterator.next();
			         System.out.print("key is: "+ e.getKey() + " & Value is: ");
			         System.out.println(e.getValue());
			      }
			
	}     
			 public static void getEmpById()
			 {
				 System.out.println("enter employeeID");
				 int id=sc.nextInt();
				Employee res=empservice.getEmpById(id);
				
				
				if(res!=null) {
			System.out.println(res);
			
				 
			 }
				
				else
        		{
        			try {
        				throw new EmployeeException(null);
        			} catch (EmployeeException e) {
        				
        				e.getStackTrace();
        			}
					
			 }
}
			 public static void deleteEmp()
			 {
				 System.out.println("enter employeeID");
				 int id=sc.nextInt();
				 HashMap<Integer, Employee> hs=empservice.fetchAllEmp();
				 try {
			if(hs.containsKey(id))
			{
				 HashMap<Integer, Employee> hs1=empservice.deleteEmp(id);
				 System.out.println(hs1);
			}
				
				else
        		{
					throw new EmployeeException(id);
        			}}
			catch (EmployeeException e) {
        				
        				e.getStackTrace();
        			}
        			
			 
}
			 public static void sortByName()
			 
			 {
		List<Employee> l=empservice.sortEmpByName();
		
System.out.println("sorting of employee by name");
			Iterator<Employee> i=l.iterator();
			while(i.hasNext())
				{
				System.out.println(i.next());
				}
		
			 }


			 public static void updateEmp() 
			 {
				 System.out.println("enter employeeID");
				 int id=sc.nextInt();
				Employee res=empservice.getEmpById(id);
				System.out.println("enter  employee id to be updated");
				int empId=sc.nextInt();
				System.out.println("enter employee name to be updated");
				String empName=sc.next();
				System.out.println("enter employee sal to be updated");
				float empSal=sc.nextFloat();
			
				res.setEmpId(empId);
				res.setEmpName(empName);
				
				res.setEmpSal(empSal);
				System.out.println(res);
				
}
}


		                    	
			  		




