package com.cg.emp.exception;

public class EmployeeException  extends Exception
{

	public EmployeeException(String s) {
		System.out.println(" invalid");
		
	}
	public EmployeeException(int id) {
		System.out.println(" entered employee id does not exist");
		
	}
	

}
