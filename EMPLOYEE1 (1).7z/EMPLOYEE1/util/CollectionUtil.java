package com.cg.emp.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import com.cg.emp.entity.Employee;

public class CollectionUtil {
 private static HashMap<Integer,Employee> empSet=new HashMap<Integer,Employee>();
 private static List<Employee> list=new ArrayList<Employee>();

 static
 {
	 empSet.put(1393, new Employee(1393, "CHANDU",50000.0f, LocalDate.of(2019,Month.MARCH, 29)));
	 empSet.put(1394, new Employee(1394, "BINDHU",50000.0f, LocalDate.of(2018,Month.DECEMBER, 9)));
	 empSet.put(1395, new Employee(1395, "DHANU",50000.0f, LocalDate.of(2019,Month.JANUARY, 19)));
	 empSet.put(1396, new Employee(1396, "ZAID",50000.0f, LocalDate.of(2017,Month.JUNE, 26)));
	 empSet.put(1397, new Employee(1397, "MARY",50000.0f, LocalDate.of(2018,Month.MAY, 20)));
	
 }

static
{
	list.add( new Employee(1393, "CHANDU",50000.0f, LocalDate.of(2019,Month.MARCH, 29)));
	list.add(new Employee(1394, "BINDHU",50000.0f, LocalDate.of(2018,Month.DECEMBER, 9)));
	list.add( new Employee(1395, "DHANU",50000.0f, LocalDate.of(2019,Month.JANUARY, 19)));
	list.add(new Employee(1396, "ZAID",50000.0f, LocalDate.of(2017,Month.JUNE, 26)));
	list.add( new Employee(1397, "MARY",50000.0f, LocalDate.of(2018,Month.MAY, 20)));
	
}
 public static void addEmp(Integer empid,Employee emp)
 {
	 empSet.put(empid, emp);
 }

public static HashMap<Integer, Employee> fetchAllDetails() {
	
	return empSet;
}
public static Employee getEmpById(int empId)
{
	
	return empSet.get(empId);
}
public static HashMap<Integer, Employee> remove(int empid)
{
	 empSet.remove(empid);
	 return empSet;
}

public static Employee updateEmp(int empid,String newName,float newSalary)
{
return empSet.get(newName);
}

public static List<Employee> SortByName()

{
	Collection<Employee> v=empSet.values();
	Collections.sort(list, Employee.getcompname());
   return list;

}
}