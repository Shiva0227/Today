package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.DAO.EmployeeDAO;
import com.cg.emp.DAO.EmployeeDAOImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	
	EmployeeDAO employeeDAO=new EmployeeDAOImpl();
	@Override
	public int addEmployee(Integer empid,Employee ee) throws EmployeeException {
		employeeDAO.addEmployee(empid,ee);
		return ee.getEmpId();
	}

	@Override
	public HashMap<Integer, Employee> fetchAllEmp() {
		HashMap<Integer, Employee> hs=employeeDAO.fetchAllEmp();
		return hs;
	}

	@Override
	public Employee getEmpById(int empId) {
	Employee e=	employeeDAO.getEmpById(empId);
		return e;
	}

	@Override
	public List<Employee> sortEmpByName() {
		List<Employee> e=employeeDAO.sortEmpByName();
		return e;
	}

	@Override
	public HashMap<Integer,Employee> deleteEmp(int empId) {
		 HashMap<Integer,Employee> hs=employeeDAO.deleteEmp(empId);
		return hs;
	}
@Override
	public Employee updateEmp(int empid ,String newName,float newSalary) {
		Employee e=employeeDAO.updateEmp(empid,newName,newSalary);
		return e;
		
	}
@Override
	public boolean validateName(String s) throws EmployeeException
	{
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{3,9}");
		Matcher m=p.matcher(s)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
	public boolean validateEid(String h) throws EmployeeException
	{
		Pattern p=Pattern.compile("[0-9]{4}");
		Matcher m=p.matcher(h)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
	public boolean validateSal(String sl) throws EmployeeException
	{
		Pattern p=Pattern.compile("[0-9]{6}");
		Matcher m=p.matcher(sl)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
}
