package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService {
public int addEmployee(Integer empid,Employee ee) throws EmployeeException;//employee object is added//
public HashMap<Integer,Employee> fetchAllEmp();
public Employee getEmpById(int empId);

public HashMap<Integer,Employee> deleteEmp(int empId);
public Employee updateEmp(int empid ,String newName,float newSalary);
public boolean validateName(String s) throws EmployeeException;
public boolean validateEid(String h) throws EmployeeException;
public boolean validateSal(String sl) throws EmployeeException;
public List<Employee> sortEmpByName();


}
