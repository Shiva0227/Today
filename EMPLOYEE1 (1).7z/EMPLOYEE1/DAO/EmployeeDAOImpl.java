package com.cg.emp.DAO;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public int addEmployee(Integer empid,Employee ee) throws EmployeeException {
	
		CollectionUtil.addEmp(empid, ee);
		
		
		return ee.getEmpId();//only fetching id from employee object//
	}

	@Override
	public HashMap<Integer, Employee> fetchAllEmp() {
	HashMap<Integer, Employee> hs=CollectionUtil.fetchAllDetails();
	
	return hs;
	}

	@Override
	public Employee getEmpById(int empId) {
		
		Employee e=CollectionUtil.getEmpById(empId);
		return e;
	}

	@Override
	public List<Employee> sortEmpByName() {
		List<Employee> e=CollectionUtil.SortByName();
		return e;
	}

	@Override
	public HashMap<Integer, Employee> deleteEmp(int empId) {
		HashMap<Integer, Employee> hs=CollectionUtil.remove(empId);
		return hs;
	}

	public Employee updateEmp (int empid ,String newName,float newSalary) {
		Employee e=CollectionUtil.updateEmp(empid,newName,newSalary);
	return e;
	
	}

}
