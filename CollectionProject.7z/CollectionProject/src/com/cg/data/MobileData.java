package com.cg.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import com.cg.bean.Account;

public class MobileData {
 static Map <String,Account>data;
//
//=new HashMap<String,Account>();
 //ArrayList list;
 /*TreeMap<String, Account> data1=new TreeMap<String,Account>();
 data1.add(new Account("prepaid","shiva",200));
 data1.add(new Account("prepaid","asn",300));
 data1.add(new Account("prepaid","nikhil",400));*/
public MobileData() {
//data=new TreeMap<String,Account>();
/*list=new ArrayList<>();


list.add(new Account("prepaid","shiva",200));
list.add(new Account("prepaid","asn",300));
list.add(new Account("prepaid","nikhil",400));*/
	

	
data=new HashMap<String,Account>();
data.put("1234567890", new Account("prepaid", "Shiva", 1000));
data.put("0987654321", new Account("prepaid", "Asn", 100));

data.put("1357924680", new Account("prepaid", "Nikhil",200));

data.put("2468013579", new Account("prepaid", "krishna", 300));

data.put("9738542153", new Account("prepaid", "niki", 344));
}

/*for(Account a:list)
{
	System.out.println(a.getAccountBalance()+" "+a.getCustomerName()+" "+a.getAccountBalance());
}
Collection.sort(list);

}*/

public Account getAccountDetails(String mobileNo)
{
	Account acc=data.get(mobileNo);
	return acc;
}

public static  double getviewBalance(String MobileNo)
{
	Account acc=data.get(MobileNo);
	return acc.getAccountBalance();
}
}
