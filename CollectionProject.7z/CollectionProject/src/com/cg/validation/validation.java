package com.cg.validation;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;
import java.util.Scanner;

public class validation {
	
	public boolean atype(String accountType)
	
	{
		Pattern p=Pattern.compile("[A-Za-z]{1,10}");
		Matcher m=p.matcher(accountType);
		if(m.matches())
		{
			return true;
		}
		
			return false;
		}
	
public boolean cname(String customerName)
	
	{
		Pattern p=Pattern.compile("[A-Za-z]{1,10}");
		Matcher m=p.matcher(customerName);
		if(m.matches())
		{
			return true;
		}
		
			return false;
		}

public boolean abalance(String accountBalance)

{
	Pattern p=Pattern.compile("[A-Za-z]{1,10}");
	Matcher m=p.matcher(accountBalance);
	if(m.matches())
	{
		return true;
	}
	
		return false;
	}
public static boolean mno(String mobileNo)

{
	Pattern p=Pattern.compile("[0-9]{10}");
	Matcher m=p.matcher(mobileNo);
	if(m.matches())
	{
		return true;
	}
	
		return false;
	}




}


