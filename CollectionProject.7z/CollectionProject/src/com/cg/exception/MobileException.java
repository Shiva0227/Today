package com.cg.exception;

public class MobileException extends Exception {

	public MobileException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
