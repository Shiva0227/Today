package com.cg.ui;



import java.util.Collections;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.data.MobileData;
import com.cg.exception.MobileException;
import com.cg.validation.validation;

public class RunMain {

	 static MobileData mobileData;
	public static void main(String[] args) throws Exception {
	System.out.println("**MENU**");
	System.out.println("1.Account Details");
	System.out.println("2.Account Balance Enquiry");
	System.out.println("3.Exit");
	
	Scanner sc=new Scanner(System.in);
	
	int input=sc.nextInt();
	switch(input)
	{
	case 1:
		AccountDetails();
		
		break;
		
	case 2:viewBalance();
		  break;
		  
	case 3:
		System.exit(0);
	}

	}
	
	public static void AccountDetails() throws Exception 
	{
		System.out.println("1.Enter Mobile Number to get Details");
		Scanner scanner=new Scanner(System.in);
		String mobileNo=scanner.next();
		validation v=new validation();
		boolean result=v.mno(mobileNo);
		//if(result==true)
		if(result==true)
		{
			System.out.println("Verified");
		}
		else
		{
			System.out.println("Invalid Number");
			System.exit(0);
		}
	
	//Invoke validateMobileno() and add validation
		Account acc=getAccountDetails(mobileNo);
		System.out.println(acc);
	}
	
	public static void viewBalance() throws Exception 
	{
		System.out.println("1.Enter Mobile Number to get balance");
		Scanner scanner=new Scanner(System.in);
		String mobileNo=scanner.next();
		validation v=new validation();
		boolean result=v.mno(mobileNo);
		
		if(result==true)
		{
			System.out.println("Verified");
		}
		else
		{
			System.out.println("Invalid Number");
			System.exit(0);
		}
	
		double acc=getviewBalance(mobileNo);
		System.out.println(acc);
		
		
		/*
		Collections.sort(data, new Sortbycustomername()); 

		System.out.println("\nSorted by name"); 
		for (int i=0; i<data.size(); i++) 
		    System.out.println(ar.get(i)); */

	}
	
	public static Account getAccountDetails(String mobileNo)
	{
		Account acc;
		mobileData=new MobileData();
		acc=mobileData.getAccountDetails(mobileNo);
		return acc;
	}
	
	public static  double getviewBalance(String mobileNo)
	{
		double acc;
		mobileData=new MobileData();
		acc=MobileData.getviewBalance(mobileNo);
		return acc;
	}
	}

